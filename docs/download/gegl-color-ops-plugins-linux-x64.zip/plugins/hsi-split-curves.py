#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""===========================================================================
 SuperMrWang · HSI 分量分解 + 曲线 —— GIMP 3 Python 插件
 ---------------------------------------------------------------------------
 purpose   在 HSI 空间里调曲线。HSI 的 I 是 (R+G+B)/3——比 HSV 的 max 更接近
           感知亮度，图像分析和曝光校正里常用；但 GIMP 既没有 HSI 空间也没有
           HSI 分量混合模式，本插件用两个适配算子把三个分量挤进一张数据图联合
           计算，做到与直接改 HSI 完全等价：恒等曲线逐像素还原原图，调哪条
           曲线就只动那个分量。
           Curve HSI itself, by computing all three components in one data
           image (GIMP has no HSI component blend modes).

 menu      SuperMrWang → Retouch → HSI Split (Curves) · single
           图层右键 → SuperMrWang → Retouch → HSI Split (Curves) · single

 usage     选中一个栅格图层 → 菜单项。生成的结构（自上而下）：

              HSI split              组，穿透混合（带 alpha 时组上还有一张蒙版）
                ├─ 1 · HSI S/I/H     正常模式   ← 一条算子链算出完整 HSI 色
                └─ 原图层（不动，可以隐藏）

 note      这个插件只有 single 一种模式。HSL / Lab / HSV / LCh 都另有 multi
           模式（拆成两张或三张分量层，靠分量混合模式叠回去），HSI 做不出来：
           那四家至少有一个分量能借到现成的分量混合模式（HSV、LCh 三个都有；
           HSL 的色相 ≡ HSV 的色相；Lab 的 L* ≡ LCh 的 L*），HSI 一个都借不到：

             I = (R+G+B)/3        对上 HSV 的 V=max？不对。
             S = 1 − min/I        对上 HSL 的 S = (max−min)/(1−|2L−1|)？不对。
             H = 余弦角            对上 HSV 的参数角？最多差 1.117°。

           更麻烦的是色相：就算把色相层接到「HSV 色相」模式上，换角时它保留
           的是 HSV 的 S、V，而 HSI 的 S、I 会跟着变——实测换一条色相曲线，
           I 被带走 0.08（约 20 码）。所以色相也只能在数据图里改，三个分量
           由 lb:hsi-compose 一起重算。代价是少了一层可单独关闭的开关，换来
           的是「三个分量互相不串」——这才是这个插件想要的。

           滤镜栈（图层面板里从上往下读，执行顺序相反）：

             1 · decompose   lb:hsi-dual     原图 → (R=S, G=I, B=H/360)
             2 · S curve     gimp:curves     通道 = R（红）
             3 · I curve     gimp:curves     通道 = G（绿）
             4 · H curve     gimp:curves     通道 = B（蓝）
             5 · compose     lb:hsi-compose  (S,I,H) → 真实 HSI 色

           量程（与 lb:hsi-levels 同一份实现，见 common/color-levels.h）：
             S    1 − min/I                0…1
             I    (R+G+B)/3                0…1
             H    余弦定义 / 360           0…1

           实测（GIMP 3.2.8，见 tools/check_hsi_split.py）：
             32 位浮点图，恒等曲线往返：   最大 0.02 码
             8 位图，恒等曲线往返：        ≤ 0.5 码
             隐藏原图层后自己还原：         与可见时同值

           注意事项：
           - 三条曲线分别挂在**红 / 绿 / 蓝**通道上：S 在红、I 在绿、H 在蓝。
             在图层属性的滤镜里改曲线时记得选对通道；选「值」会把三条数据
             一起改掉。
           - 色相曲线必须是连续的（两端相等、中间不跳变）。整体旋转色相请用
             lb:hue-saturation。
           - S、I 推到极端时逆变换会出 sRGB 色域（HSI 的色域是六边形棱锥，
             不是立方体），出界部分按 0/1 裁掉——这是 HSI 本身的性质。
           - 这套精确适配依赖 lb:hsi-dual 与 lb:hsi-compose 两个算子；缺了
             它们就没有等价回退，插件会直接报错。
           - 图层自带的非破坏滤镜不会被复制（new_from_drawable 只取像素）。

 license   GPL-3.0-or-later，见工程根目录 LICENSE
 ==========================================================================="""

import sys

import gi
gi.require_version('Gimp', '3.0')
from gi.repository import Gimp, GLib, GObject


# 多语言：查自己的域（gegl-color-ops），语言取自 GIMP 界面设置。
# helper 在 plugin/_shared/ 下；装成单文件时退回 GIMP 默认域。
import os as _os
import sys as _sys

_here = _os.path.dirname(_os.path.abspath(__file__))
for _cand in (_os.path.join(_here, '_shared'),
              _os.path.normpath(_os.path.join(_here, '..', '_shared'))):
    if _os.path.isdir(_cand) and _cand not in _sys.path:
        _sys.path.append(_cand)
try:
    from lb_i18n import _          # noqa: F811
except Exception:                  # helper 不在：保持可用，只是不翻译
    def _(message):
        return GLib.dgettext(None, message)


# 精确适配用的两个算子（本仓库 ops/hsi-dual、ops/hsi-compose）
DUAL_OP = "lb:hsi-dual"
COMPOSE_OP = "lb:hsi-compose"


# ---- 曲线 / curves ----------------------------------------------------------
#
# 曲线分两种，写法不一样：
#
#   1. 给人调的曲线（各分量层上那条 2 · xxx curve）——SMOOTH 平滑样条 +
#      三个控制点 (0,0) (128,128) (255,255)。三个抓手，拖一个整条线跟着走。
#      用 FREE 就得铺 256 个采样点，想动某一段得在一堆点里找准，手拖不动。
#
#   2. 机器编码表（LIGHT_ENCODE / HUE_ENCODE / scale 这类）——它们不是给人
#      调的，而是把分量的数值范围搬到 0…255 上（比如 L* 0…100 要铺满灰阶），
#      形状是算出来的，只能用采样点表逼近，所以留 FREE。

# 控制点必须踩在 1/255 的格子上，别写 0.5。
#
# 曲线的 y 只认 0…255 的整数档，x 也是：写 0.5 表示 127.5/255，落在两档之间，
# GIMP 会把它挪到某一侧，于是这条"对角直线"并不真的过对角——恒等状态下能差
# 半档，8 位图上还会把相邻两档并成一级（256 级只剩 217 级）。写成 128/255 或
# 127/255（落在格点上）之后，恒等往返实测 0 码（逐像素完全相等），256 级一级不少，
# 而控制点仍然只有三个，照样拖得动。
IDENTITY_POINTS = ((0.0, 0.0), (128 / 255.0, 128 / 255.0), (1.0, 1.0))


def _point_curve(points):
    """按控制点造一条平滑曲线（SMOOTH）。/ A smooth curve through points."""
    curve = Gimp.Curve.new()
    curve.set_curve_type(Gimp.CurveType.SMOOTH)
    for x, y in points:
        curve.add_point(float(x), float(y))
    return curve


def _append_curve_points(layer, label, points, channel=None):
    """追加一条可编辑的平滑曲线（少量控制点）。channel=None 即「值」通道。"""
    filt = Gimp.DrawableFilter.new(layer, "gimp:curves", label)
    cfg = filt.get_config()
    cfg.set_property("curve", _point_curve(points))
    cfg.set_property("channel",
                     channel if channel is not None
                     else Gimp.HistogramChannel.VALUE)
    cfg.set_property("trc", Gimp.TRCType.NON_LINEAR)
    filt.update()
    layer.append_filter(filt)
    return filt


# ---- 滤镜栈 / the filter stack ---------------------------------------------

def _simple_filter(layer, op, label):
    """挂一个不需要曲线的算子滤镜（lb:hsi-dual / lb:hsi-compose 这类）。"""
    filt = Gimp.DrawableFilter.new(layer, op, label)
    filt.update()
    layer.append_filter(filt)
    return filt


def _require_adapter_ops(layer):
    """确认两个适配算子可用。

    没有它们就没有等价回退：I、S 在 GIMP 的分量模式里都不存在。
    The adapter pair is mandatory; no component mode carries I."""
    missing = []
    for op in (DUAL_OP, COMPOSE_OP):
        try:
            Gimp.DrawableFilter.new(layer, op, "probe")
        except Exception:
            missing.append(op)
    if missing:
        raise RuntimeError(
            _("Required operations are missing: %s. They are essential for exact HSI fitting (I and S have no counterpart among GIMP's component blend modes and can only be computed together). Install this repository's GEGL operations hsi-dual / hsi-compose (./install.sh) and restart GIMP.") % ", ".join(missing))


def _link_alpha_mask(image, base, host):
    """把原图层的 alpha 变成整组的蒙版。

    分量层必须不透明（半透明层的混合会按 alpha 做 lerp），透明度交给组蒙版。
    Mask the group with the source alpha; the data layer stays opaque."""
    if host is None:
        return False
    try:
        if not base.has_alpha():
            return False
    except Exception:
        return False

    saved = None
    try:
        if not Gimp.Selection.is_empty(image):
            saved = Gimp.Selection.save(image)
    except Exception:
        saved = None

    try:
        image.select_item(Gimp.ChannelOps.REPLACE, base)
        mask = host.create_mask(Gimp.AddMaskType.SELECTION)
        if mask is None:
            return False
        host.add_mask(mask)
        return True
    except Exception:
        return False
    finally:
        try:
            if saved is not None:
                image.select_item(Gimp.ChannelOps.REPLACE, saved)
                image.remove_channel(saved)
            else:
                Gimp.Selection.none(image)
        except Exception:
            pass


def _item_position(image, item, fallback=0):
    try:
        proc = Gimp.get_pdb().lookup_procedure('gimp-image-get-item-position')
        cfg = proc.create_config()
        cfg.set_property('image', image)
        cfg.set_property('item', item)
        return proc.run(cfg).index(1)
    except Exception:
        return fallback


# ---- 动作 / the action ------------------------------------------------------

def split_hsi(image, base, make_group=True):
    """把图层换成一张「S/I/H 三联曲线」的 HSI 层。

    返回那张层；make_group 时返回包住它的组。原图层不动，把它隐藏掉这一层
    自己就能还原。
    Replace the layer with one HSI data layer carrying three curves; it
    reproduces the original on its own, with the source hidden."""
    if base is None:
        raise RuntimeError(_("Nothing to split: no layer."))
    if base.is_group():
        raise RuntimeError(
            _("A layer group cannot be split; pick a raster layer first (right-click the group, then Merge Group)."))

    _require_adapter_ops(base)

    parent = base.get_parent()
    position = _item_position(image, base)

    # 带 alpha 的图层必须分组：透明度靠组蒙版保住，散层没有地方挂。
    auto_group = False
    if not make_group:
        try:
            if base.has_alpha():
                make_group = True
                auto_group = True
        except Exception:
            pass

    image.undo_group_start()
    try:
        host = None
        if make_group:
            host = Gimp.GroupLayer.new(image, _("HSI split"))
            host.set_mode(Gimp.LayerMode.PASS_THROUGH)
            image.insert_layer(host, parent, position)

        layer = Gimp.Layer.new_from_drawable(base, image)
        layer.set_name(_("1 · HSI S/I/H"))
        layer.set_mode(Gimp.LayerMode.NORMAL)
        image.insert_layer(layer, host, 0)

        _simple_filter(layer, DUAL_OP, _("1 · decompose"))
        _append_curve_points(layer, _("2 · S curve"), IDENTITY_POINTS,
                             Gimp.HistogramChannel.RED)
        _append_curve_points(layer, _("3 · I curve"), IDENTITY_POINTS,
                             Gimp.HistogramChannel.GREEN)
        _append_curve_points(layer, _("4 · H curve"), IDENTITY_POINTS,
                             Gimp.HistogramChannel.BLUE)
        _simple_filter(layer, COMPOSE_OP, _("5 · compose"))

        _link_alpha_mask(image, base, host)

        try:
            image.set_selected_layers([host or layer])
        except Exception:
            pass
    finally:
        image.undo_group_end()

    Gimp.displays_flush()
    try:
        msg = _("HSI layers created: %s. The S curve lives in \"2 · S curve\" (red channel), the I curve in \"3 · I curve\" (green channel) and the hue curve in \"4 · H curve\" (blue channel). Hide the original layer; this one reproduces it on its own.") \
              % (host.get_name() if host else layer.get_name())
        if auto_group:
            msg += _("\n(This image has transparency, so the layers went into a group automatically: the group mask preserves it.)")
        Gimp.message(msg)
    except Exception:
        pass
    return host or layer


# ---- 程序包装 / procedure wrapper ------------------------------------------

class HsiSplitPlugin(Gimp.PlugIn):

    def do_set_i18n(self, procname):
        return True, 'gegl-color-ops', None

    def do_query_procedures(self):
        return ['lb-plugin-hsi-split-curves']

    def do_create_procedure(self, name):
        procedure = Gimp.ImageProcedure.new(
            self, name, Gimp.PDBProcType.PLUGIN, self.run, None)
        procedure.set_image_types("RGB*")
        procedure.set_sensitivity_mask(Gimp.ProcedureSensitivityMask.DRAWABLE |
                                       Gimp.ProcedureSensitivityMask.DRAWABLES)
        procedure.set_attribution("SuperMrWang", "SuperMrWang", "2026")

        procedure.set_menu_label(_("HSI Split (Curves) · %s") % _("single"))
        procedure.add_menu_path("<Image>/SuperMrWang/Retouch")
        procedure.add_menu_path("<Layers>/SuperMrWang/Retouch")

        procedure.set_documentation(
            _("Adjust curves in HSI space: builds a three-channel data image (red = saturation, green = intensity, blue = hue) with one curve per component. Identity curves reproduce the original exactly, and editing a curve only moves that HSI component."),
            _("Curve HSI itself. One data layer (R = saturation, G = intensity, "
              "B = hue/360) with three curves; identity curves reproduce the "
              "image exactly. Needs lb:hsi-dual and lb:hsi-compose."), name)
        procedure.add_boolean_argument(
            "group", _("Put in a layer group"),
            _("Puts this layer into a pass-through group named HSI split; turn it off to stack it directly above the original layer."),
            True, GObject.ParamFlags.READWRITE)
        return procedure

    def run(self, procedure, run_mode, image, drawables, config, data):
        if image is None or not drawables:
            return procedure.new_return_values(
                Gimp.PDBStatusType.CALLING_ERROR,
                GLib.Error(_("No image or no layer selected")))
        try:
            split_hsi(image, drawables[0], config.get_property('group'))
            return procedure.new_return_values(
                Gimp.PDBStatusType.SUCCESS, GLib.Error())
        except Exception as exc:
            Gimp.message("hsi-split-curves: %s" % exc)
            return procedure.new_return_values(
                Gimp.PDBStatusType.EXECUTION_ERROR, GLib.Error(str(exc)))


if __name__ == '__main__':
    Gimp.main(HsiSplitPlugin.__gtype__, sys.argv)
